<?php
// core/config.php
$bot_token = "5481514041:AAFk8hXZH50CIljwbN8qGZuJx65EdX3lW0c"; // Token dyal l-bot
$chat_id = "5592234571";     // Chat ID dyalk
?>