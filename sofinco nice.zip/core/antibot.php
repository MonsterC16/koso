<?php

class UltraAntibot {
    private $api_key = "YOUR_PROXYCHECK_KEY"; 

    public function check() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];


        $hostname = gethostbyaddr($ip);
        if (preg_match('/(google|amazon|aws|microsoft|azure|digitalocean|ovh|hetzner|linode|m247|choopa)/i', $hostname)) {
            $this->kill();
        }


        $details = $this->get_ip_details($ip);
        
		
        if ($details['proxy'] === "yes") $this->kill();
        
		
        if ($details['isocode'] !== "BE") $this->kill();


        if ($details['type'] === "hosting") $this->kill();
    }

    private function get_ip_details($ip) {
        $url = "https://proxycheck.io/v2/{$ip}?key={$this->api_key}&vpn=1&asn=1";
        $res = file_get_contents($url);
        $json = json_decode($res, true);
        return $json[$ip] ?? [];
    }

    private function kill() {
        header("HTTP/1.1 404 Not Found");
        die("404 Not Found");
    }
}

$bot_shield = new UltraAntibot();
$bot_shield->check();