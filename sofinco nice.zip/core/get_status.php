<?php
header('Content-Type: application/json');
$ip = $_SERVER['REMOTE_ADDR'];
$status_file = "status_$ip.json";
$current_time = time();

if (file_exists($status_file)) {
    $data = json_decode(file_get_contents($status_file), true);
    $data['last_seen'] = $current_time;
    file_put_contents($status_file, json_encode($data));
    echo json_encode($data);
} else {
    echo json_encode(["action" => "waiting", "last_seen" => $current_time]);
}
?>